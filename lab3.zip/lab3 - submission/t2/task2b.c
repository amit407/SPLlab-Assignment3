#include <stdlib.h>
#include <stdio.h>
#include <string.h>
typedef struct link link;

typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    unsigned char* sig;
} virus;

struct link{
    link *nextVirus;
    virus *vir;
};

typedef struct fun_desc{
    char *name;
    void (*fun)(void);
} fun_desc;

virus *readVirus(FILE* file){
    virus *vir = (virus *)malloc(sizeof(virus));
    if (fread(vir, 1, 18, file) != 18)
        return NULL;
    unsigned short len = vir->SigSize;
    unsigned char * buffer = (unsigned char *)malloc(len);
    if (fread(buffer, 1, len, file) != len)
        return NULL;
    vir->sig = buffer;
    return vir;
} 

void printVirus(virus *virus, FILE *output){
    fprintf(output, "%s %s\n", "Virus name:", virus->virusName);
    fprintf(output, "%s %d\n", "Virus size:", virus->SigSize);
    fprintf(output, "%s\n", "signature:");
    unsigned short length = virus->SigSize;
    for (int i=0; i<length; i++){
        fprintf(output, "%02X ", virus->sig[i]);
    }
}

void list_print(link *virus_list, FILE *output){
    link *curr_virus = virus_list;
    while (curr_virus != NULL){
        printVirus(curr_virus->vir, output);
        fprintf(output, "\n\n");
        curr_virus = curr_virus->nextVirus;
    }
}

link *list_append(link *virus_list, virus *data){  //add new link to the end of the list
    if (virus_list == NULL){
        virus_list = (link *)malloc(sizeof(link));
        virus_list->vir = data;
        virus_list->nextVirus = NULL;
    }
    else{
        link *curr = virus_list;
        while (curr->nextVirus != NULL){
            curr = curr->nextVirus;
        }
        link *toAdd = (link *)malloc(sizeof(link));
        toAdd->vir = data;
        toAdd->nextVirus = NULL;
        curr->nextVirus = toAdd;
    }
    return virus_list;          //return the first link of the list
}

void list_free(link *virus_list){
    link *curr = virus_list;
    while (curr != NULL){
        link *next = curr->nextVirus;
        free(curr->vir);
        free(curr);
        curr = next;
    }
}

link *load_signatures(FILE *f){    //inserting all viruses from a file to a list
    link *vir_list = NULL;
    virus *vir;
    while ((vir = readVirus(f)) != NULL){
        vir_list = list_append(vir_list,vir);
    }
    return vir_list;
}

void detect_virus(char *buffer, unsigned int size, link *virus_list){
    link *curr = virus_list;
    while (curr != NULL){    // searching for all the viruses in the list
        virus *v = curr->vir;
        char *signature = v->sig;
        unsigned short sig_size = v->SigSize;
        for (int i = 0; i < size-sig_size+1; i++){
            if (memcmp(&buffer[i], signature, sig_size) == 0){  //found signature in the buffer
                printf("\nStarting byte location: %d\n", i);
                printf("Virus name: %s\n", v->virusName);
                printf("Size of virus signature: %d\n", sig_size);
            }
        }
        curr = curr->nextVirus;
    }
}

void detect_viruses(char *file_name, link *virus_list){
    char buffer[10000] = {0};
    FILE *f = fopen(file_name, "rb");
    fseek(f, 0, SEEK_END);
    int file_size = ftell(f);   //size of file
    fseek(f, 0, SEEK_SET);
    fread(buffer, 1, file_size, f);
    detect_virus(buffer, file_size, virus_list);
}

void kill_virus(char *fileName, int byte_offset, int signature_size){
    FILE *f = fopen(fileName, "r+");
    fseek(f, byte_offset, SEEK_SET);
    char buf[signature_size];
    for (int i =0; i<strlen(buf); i++){
        buf[i] = 0x90;
    }
    fwrite(buf, sizeof(char), signature_size, f);
    fclose(f);
}

void fix_file(char *file_name){
    getc(stdin);    //to get rid of the \n
    char byte_location[5] = {0}; 
    printf("insert byte location:\n");
    fgets(byte_location, 5, stdin);
    int len = strlen(byte_location);
    byte_location[len-1] = '\0';
    int byte_loc = atoi(byte_location);
    printf("\ninsert signature size:\n");
    char sig_size[5] = {0};
    fgets(sig_size, 5, stdin);
    int len2 = strlen(sig_size);
    sig_size[len2-1] = '\0';
    int signature_size = atoi(sig_size);
    kill_virus(file_name, byte_loc, signature_size);
}

void quit(){
    exit(0);
}


int main (int argc, char **argv){
    fun_desc menu[] = { {"Load signatures", load_signatures} , {"Print signatures", list_print} ,
    {"Detect viruses", detect_viruses} , {"Fix file", fix_file} , {"Quit", quit} , {NULL, NULL} }; 
    int menu_length = sizeof(menu)/sizeof(fun_desc);
    while(1){
        printf ("%s" , "\nPlease choose a function: \n");
        for (int i = 1 ; i < menu_length ; i++){
            printf ("%d)  %s\n" , i , menu[i-1].name);
        }
        printf("%s  ", "Option :");
        char c;
        int should_loop = 1;
        while(should_loop == 1){
            c = getc(stdin);
            if(c == EOF){
                printf("\n%s\n", "DONE.");
                return(0);
            }
            if (c == '\n')
                continue;
            should_loop = 0;    
        }
        printf("\n");
        int digit = c -'0';
        if (digit >= 1 && digit < menu_length){
            printf("%s\n", "Within bounds");
        }
        else{
            printf("%s\n", "Not within bounds");
            exit(0);
        }
        char file_name[4096] = {0};   //max length of path
        link *vir_list;
        if (digit == 1){
            getc(stdin);    //to get rid of the \n
            printf("insert a file name:\n");
            fgets(file_name, 4096, stdin);
            int len = strlen(file_name);
            file_name[len-1] = '\0';
            FILE *f = fopen(file_name,"rb");
            fseek(f, 4, SEEK_SET);      //ignore the first 4 bytes
            vir_list = load_signatures(f);
        }
        if (digit == 2){
            list_print(vir_list, stdout);
        }
        if (digit == 3){
            detect_viruses(argv[1], vir_list);
        }
        if (digit == 4){
            fix_file(argv[1]);
        }
        if (digit == 5){
            quit();
        }
    }
    return 0;
}


